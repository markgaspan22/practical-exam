class AttendancesController < ApplicationController
end
