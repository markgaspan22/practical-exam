class EventsController < ApplicationController
end
